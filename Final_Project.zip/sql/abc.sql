create table abc (drink_name VARCHAR(16), main VARCHAR(20), amount1 DEC(3,1), second VARCHAR(20), amount2 DEC(4,2) );
INSERT INTO abc VALUES ('Blackthorn', 'tonic water', 1.5, 'pineapple juice',1);
select * from abc;