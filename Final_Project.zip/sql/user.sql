SELECT * FROM project.user;
insert into user values(1001,'abcd',987654321,'abc@123@xyz');
insert into user values(1002,'user1',123456789,'user1001');
